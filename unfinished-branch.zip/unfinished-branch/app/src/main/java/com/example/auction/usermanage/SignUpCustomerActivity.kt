package com.example.auction.usermanage

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.auction.R

class SignUpCustomerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.sign_up_customer) // sign_up_customer.xml 레이아웃을 사용합니다.

        // 고객 회원가입 로직 추가
    }
}
