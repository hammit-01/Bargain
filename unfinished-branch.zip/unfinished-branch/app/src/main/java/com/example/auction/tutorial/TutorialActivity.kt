package com.example.auction.tutorial

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager.widget.ViewPager
import com.example.auction.MainActivity
import com.example.auction.R
import com.example.auction.adapter.TutorialPagerAdapter
import com.tbuonomo.viewpagerdotsindicator.DotsIndicator

class TutorialActivity : AppCompatActivity() {

    private lateinit var viewPager: ViewPager
    private lateinit var dotsIndicator: DotsIndicator
    private lateinit var btnGetStarted: Button
    private lateinit var viewPagerAdapter: TutorialPagerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 기존 SharedPreferences 체크 부분을 주석 처리
        // val pref = getSharedPreferences("tutorial", MODE_PRIVATE)
        // val isTutorialSeen = pref.getBoolean("isTutorialSeen", false)

        // if (isTutorialSeen) {
        //    startActivity(Intent(this, MainActivity::class.java))
        //    finish()
        // }

        setContentView(R.layout.activity_tutorial)

        viewPager = findViewById(R.id.viewPager)
        dotsIndicator = findViewById(R.id.dots_indicator)
        btnGetStarted = findViewById(R.id.btn_get_started)

        // 튜토리얼에 표시할 이미지 목록을 생성
        val tutorialImages = listOf(
            R.drawable.tutorial_image1,
            R.drawable.tutorial_image2,
            R.drawable.tutorial_image3,
            R.drawable.tutorial_image4
        )

        viewPagerAdapter = TutorialPagerAdapter(tutorialImages)
        viewPager.adapter = viewPagerAdapter

        // DotsIndicator와 ViewPager 연결
        dotsIndicator.attachTo(viewPager)

        btnGetStarted.setOnClickListener {
            // 튜토리얼 완료 상태를 기록하는 부분도 주석 처리
            // val editor = pref.edit()
            // editor.putBoolean("isTutorialSeen", true)
            // editor.apply()

            // 메인 액티비티로 이동
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}
