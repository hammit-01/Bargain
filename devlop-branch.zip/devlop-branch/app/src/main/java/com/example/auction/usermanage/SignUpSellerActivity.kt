package com.example.auction.usermanage

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.auction.R

class SignUpSellerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.sign_up_seller) // sign_up_seller.xml 레이아웃을 사용합니다.

        // 판매자 회원가입 로직 추가
    }
}
